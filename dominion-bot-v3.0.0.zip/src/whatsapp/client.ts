
import makeWASocket, {
  DisconnectReason,
  makeCacheableSignalKeyStore,
  WASocket,
  fetchLatestBaileysVersion,
  Browsers,
  proto,
  isJidGroup,
  jidNormalizedUser,
  GroupMetadata
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import pino from 'pino';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { ConnectionStatus, Message, LeadStatus, WhatsAppGroup } from '../types.js';
import { conversationService } from '../services/conversationService.js';
import { db, sanitizeKey } from '../database.js';
import { generateBotResponse } from '../services/aiService.js';
import { useMongoDBAuthState, clearBindedSession } from './mongoAuth.js';
import { logService } from '../services/logService.js';
import * as QRCode from 'qrcode';
import { Buffer } from 'buffer'; 
import { normalizeJid } from '../utils/jidUtils.js';

// GLOBAL STATE
const sessions = new Map<string, WASocket>();
const qrCache = new Map<string, string>(); 
const codeCache = new Map<string, string>(); 
const isConnecting = new Map<string, boolean>(); 
const retryMap = new Map<string, any>();

// CRASH COUNTER FOR BAD MAC DETECTION
const crashCounters = new Map<string, { count: number, lastCrash: number }>();

const msgRetryCounterCache = {
    get: (key: string) => retryMap.get(key),
    set: (key: string, value: any) => { retryMap.set(key, value); },
    del: (key: string) => { retryMap.delete(key); },
    flushAll: () => { retryMap.clear(); }
};

// Logger setup - Silent to avoid console spam in production
const logger = pino({ level: 'silent' }); 

export const ELITE_BOT_JID = '5491112345678@s.whatsapp.net';
export const ELITE_BOT_NAME = 'Simulador Neural';
export const DOMINION_NETWORK_JID = '5491110000000@s.whatsapp.net';

// --- MESSAGE EXTRACTION UTILS ---
function extractMessageContent(msg: proto.IWebMessageInfo | proto.IMessage): string | null {
    const message = (msg as any).message || msg; 
    if (!message) return null;

    if (message.protocolMessage || message.reactionMessage || message.pollUpdateMessage || message.keepInChatMessage || message.senderKeyDistributionMessage) {
        return null; 
    }

    if (message.conversation) return message.conversation;
    if (message.extendedTextMessage?.text) return message.extendedTextMessage.text;
    if (message.imageMessage?.caption) return message.imageMessage.caption;
    if (message.videoMessage?.caption) return message.videoMessage.caption;
    if (message.documentMessage?.caption) return message.documentMessage.caption;

    if (message.ephemeralMessage?.message) return extractMessageContent(message.ephemeralMessage.message);
    if (message.viewOnceMessage?.message) return extractMessageContent(message.viewOnceMessage.message);
    if (message.viewOnceMessageV2?.message) return extractMessageContent(message.viewOnceMessageV2.message);
    if (message.documentWithCaptionMessage?.message) return extractMessageContent(message.documentWithCaptionMessage.message);
    if (message.editedMessage?.message?.protocolMessage?.editedMessage) return extractMessageContent(message.editedMessage.message.protocolMessage.editedMessage);

    if (message.imageMessage) return '📷 [Imagen]';
    if (message.audioMessage) return '🎤 [Audio]';
    if (message.videoMessage) return '🎥 [Video]';
    if (message.documentMessage) return '📄 [Documento]';
    if (message.stickerMessage) return '👾 [Sticker]';
    if (message.contactMessage) return '👤 [Contacto]';
    if (message.locationMessage) return '📍 [Ubicación]';
    
    return null;
}

export function getSessionStatus(userId: string): { status: ConnectionStatus, qr?: string, pairingCode?: string } {
    const sock = sessions.get(userId);
    const qr = qrCache.get(userId);
    const code = codeCache.get(userId);

    // @ts-ignore
    if (sock?.user) return { status: ConnectionStatus.CONNECTED };
    
    if (code) return { status: ConnectionStatus.AWAITING_SCAN, pairingCode: code };
    if (qr) return { status: ConnectionStatus.AWAITING_SCAN, qr };
    
    if (isConnecting.get(userId)) return { status: ConnectionStatus.GENERATING_QR };

    return { status: ConnectionStatus.DISCONNECTED };
}

export function getSocket(userId: string): WASocket | undefined {
    return sessions.get(userId);
}

// ----------------------------------------------------------------------
// CORE CONNECTION LOGIC (STABLE v3.4 - ANTI BAD MAC)
// ----------------------------------------------------------------------
export async function connectToWhatsApp(userId: string, phoneNumber?: string, isManual: boolean = false) {
    if (isConnecting.get(userId)) return;
    
    // Clean up existing session wrapper if exists but broken
    const existingSock = sessions.get(userId);
    if (existingSock) {
        // @ts-ignore
        if (existingSock.ws && existingSock.ws.isOpen && existingSock.user) {
            return; // Already connected and healthy
        } else {
            sessions.delete(userId);
        }
    }

    try {
        isConnecting.set(userId, true);
        qrCache.delete(userId);
        codeCache.delete(userId);

        const { state, saveCreds } = await useMongoDBAuthState(userId);
        const { version } = await fetchLatestBaileysVersion();
        const user = await db.getUser(userId);

        const sock = makeWASocket({
            version,
            logger,
            printQRInTerminal: false,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, logger),
            },
            browser: Browsers.macOS('Chrome'), 
            agent: user?.settings?.proxyUrl ? new HttpsProxyAgent(user.settings.proxyUrl) as any : undefined,
            generateHighQualityLinkPreview: true,
            shouldIgnoreJid: jid => jid?.endsWith('@broadcast') || jid?.endsWith('@newsletter'),
            
            // --- STABILITY & RESILIENCE SETTINGS ---
            syncFullHistory: false, 
            markOnlineOnConnect: false, 
            
            // Aggressive Timeouts for Faster Recovery
            connectTimeoutMs: 30000, 
            defaultQueryTimeoutMs: 60000, 
            keepAliveIntervalMs: 15000, // Ping faster to detect zombies
            
            retryRequestDelayMs: 2000, 
            msgRetryCounterCache: msgRetryCounterCache, 
            
            getMessage: async (key) => {
                return undefined; 
            }
        });

        sessions.set(userId, sock);

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;
            const pairingCode = (update as any).pairingCode;

            if (qr) {
                if (phoneNumber && !codeCache.get(userId)) {
                    setTimeout(async () => {
                        try {
                            const currentSock = sessions.get(userId);
                            if (currentSock === sock && !currentSock.authState.creds.me && !codeCache.get(userId)) {
                                const code = await currentSock.requestPairingCode(phoneNumber);
                                codeCache.set(userId, code);
                            }
                        } catch (e) {
                            console.error("Pairing code error", e);
                        }
                    }, 2000);
                }
                qrCache.set(userId, await QRCode.toDataURL(qr));
            }

            if (pairingCode) {
                codeCache.set(userId, pairingCode);
            }

            if (connection === 'close') {
                isConnecting.set(userId, false);
                sessions.delete(userId);
                
                const disconnectError = lastDisconnect?.error as Boom | any;
                const statusCode = disconnectError?.output?.statusCode;
                
                // --- CRASH LOOP DETECTION (BAD MAC KILLER) ---
                const now = Date.now();
                const crashData = crashCounters.get(userId) || { count: 0, lastCrash: 0 };
                
                // If crash happened recently (within 2 mins)
                if (now - crashData.lastCrash < 120000) {
                    crashData.count++;
                } else {
                    crashData.count = 1; // Reset counter if it's been a while
                }
                crashData.lastCrash = now;
                crashCounters.set(userId, crashData);

                // Analyze Disconnect Reason
                const isLoggedOut = statusCode === DisconnectReason.loggedOut;
                const isBadSession = statusCode === DisconnectReason.badSession;
                const isConnectionLost = statusCode === DisconnectReason.connectionLost;
                const isRestartRequired = statusCode === DisconnectReason.restartRequired;
                const isTimedOut = statusCode === DisconnectReason.timedOut;

                // TACTICAL AMNESIA: If too many crashes or Bad Session, WIPE IT.
                if (crashData.count > 5 || isBadSession) {
                    logService.error(`[WA] 💀 SESIÓN CORRUPTA DETECTADA (${crashData.count} fallos). EJECUTANDO HARD RESET AUTOMÁTICO.`, null, userId);
                    await clearBindedSession(userId);
                    await db.updateUserSettings(userId, { isActive: false });
                    crashCounters.delete(userId);
                    // Do not reconnect automatically, force user to rescan to fix crypto keys
                    return; 
                }

                const shouldReconnect = !isLoggedOut;
                qrCache.delete(userId);
                codeCache.delete(userId);

                if (shouldReconnect) {
                    // Fast Reconnect for minor issues, Slow for major ones
                    const delay = isRestartRequired ? 500 : (isTimedOut ? 2000 : 5000);
                    
                    if (statusCode !== DisconnectReason.restartRequired) {
                        logService.warn(`[WA] Desconectado (${statusCode}). Reintentando en ${delay}ms...`, userId);
                    }
                    setTimeout(() => connectToWhatsApp(userId, phoneNumber), delay);
                } else {
                    logService.warn(`[WA] Sesión cerrada (Log Out). Limpiando datos.`, userId);
                    await clearBindedSession(userId);
                    await db.updateUserSettings(userId, { isActive: false });
                }

            } else if (connection === 'open') {
                isConnecting.set(userId, false);
                crashCounters.delete(userId); // Reset crash counter on success
                logService.info(`[WA] ✅ CONEXIÓN ESTABLECIDA.`, userId);
                qrCache.delete(userId);
                codeCache.delete(userId);
                
                if (sock.user?.id) {
                    const number = jidNormalizedUser(sock.user.id).split('@')[0];
                    await db.updateUser(userId, { whatsapp_number: number });
                    await db.updateUserSettings(userId, { isActive: true });
                }
            }
        });

        // Message Handling
        sock.ev.on('messages.upsert', async ({ messages, type }) => {
            if (type !== 'notify' && type !== 'append') return;

            for (const msg of messages) {
                // Ignore status updates
                if (msg.key.remoteJid === 'status@broadcast') continue;

                // --- HARD FILTER: IGNORED JIDS (PRE-PROCESSING) ---
                // Check blacklist BEFORE anything else to save CPU
                const rawJid = msg.key.remoteJid;
                const canonicalJid = normalizeJid(rawJid);
                if (!canonicalJid || canonicalJid.endsWith('@newsletter')) continue;

                if (user?.settings?.ignoredJids?.some(blocked => canonicalJid.includes(blocked))) {
                    continue; // DROP PACKET IMMEDIATELY
                }

                // Time check
                const msgTime = (typeof msg.messageTimestamp === 'number' 
                    ? msg.messageTimestamp 
                    : (msg.messageTimestamp as any)?.low) || Math.floor(Date.now() / 1000);
                
                const now = Math.floor(Date.now() / 1000);
                const ageInSeconds = now - msgTime;
                
                if (ageInSeconds > 86400) continue; // Ignore messages older than 24h

                if (!msg.message) continue;
                if (isJidGroup(canonicalJid)) continue; 

                const messageText = extractMessageContent(msg);
                if (!messageText) continue;

                const isMe = msg.key.fromMe;
                
                const userMessage: Message = {
                    id: msg.key.id || Date.now().toString(),
                    text: messageText,
                    sender: isMe ? 'owner' : 'user',
                    timestamp: new Date(msgTime * 1000).toISOString()
                };

                const contactName = msg.pushName;
                
                await conversationService.addMessage(userId, canonicalJid, userMessage, contactName);

                // --- AI TRIGGER LOGIC ---
                if (!isMe) {
                    // SILENT INGEST PROTOCOL
                    if (ageInSeconds > 300) { // Reduced to 5 mins
                        logService.debug(`[SILENT-INGEST] Msj antiguo (${ageInSeconds}s). Guardado sin respuesta.`, userId);
                        continue; 
                    }

                    logService.info(`[INBOX] 📩 ${canonicalJid}: ${messageText.substring(0, 30)}...`, userId);
                    await processAiResponseForJid(userId, canonicalJid);
                }
            }
        });

    } catch (error) {
        logService.error(`[WA] Error fatal en conexión`, error, userId);
        isConnecting.set(userId, false);
    }
}

export async function disconnectWhatsApp(userId: string) {
    const sock = sessions.get(userId);
    if (sock) {
        try {
            sock.end(undefined);
        } catch (e) {}
        sessions.delete(userId);
    }
    isConnecting.set(userId, false);
    qrCache.delete(userId);
    codeCache.delete(userId);
    await db.updateUserSettings(userId, { isActive: false });
}

export async function softResetConnection(userId: string) {
    logService.warn(`[WA] Soft Reset solicitado para usuario`, userId);
    const sock = sessions.get(userId);
    if (sock) {
        try { sock.end(undefined); } catch (e) {}
        sessions.delete(userId);
    }
    isConnecting.set(userId, false);
    qrCache.delete(userId);
    codeCache.delete(userId);
    msgRetryCounterCache.flushAll();
    // Force connect with manual flag to bypass checks
    await connectToWhatsApp(userId, undefined, true);
}

// --- SELF-HEALING SEND PROTOCOL ---
export async function sendMessage(senderId: string, jid: string, text: string, imageUrl?: string) {
    let sock = sessions.get(senderId);
    const canonicalJid = normalizeJid(jid);
    if (!canonicalJid) throw new Error("JID inválido");

    // Internal Helper for the actual send attempt
    const attemptSend = async (currentSock: WASocket) => {
        // @ts-ignore
        if (!currentSock || !currentSock.ws || !currentSock.ws.isOpen) {
            throw new Error("Socket cerrado");
        }

        // 5-Second timeout for faster failure detection
        return await Promise.race([
            (async () => {
                if (imageUrl) {
                    const buffer = imageUrl.startsWith('http') 
                        ? { url: imageUrl } 
                        : Buffer.from(imageUrl.replace(/^data:image\/\w+;base64,/, ""), 'base64');
                    return await currentSock.sendMessage(canonicalJid, { image: buffer as any, caption: text });
                } else {
                    return await currentSock.sendMessage(canonicalJid, { text });
                }
            })(),
            new Promise((_, reject) => setTimeout(() => reject(new Error("TIMEOUT_SEND")), 5000))
        ]);
    };

    try {
        // ATTEMPT 1: Normal Send
        const result = await attemptSend(sock!);
        return result as any;

    } catch (e: any) {
        // Only log if it's not a common timeout to avoid spam
        if (e.message !== 'TIMEOUT_SEND') {
            console.error(`[SEND-FAIL] Intento 1 fallido para ${canonicalJid}:`, e.message);
        }

        // CHECK IF RECOVERABLE
        if (e.message === 'TIMEOUT_SEND' || e.message === 'Socket cerrado' || e.message.includes('Stream Ended') || e.message.includes('enc-')) {
            logService.warn(`[SELF-HEALING] 🚑 Socket Zombie o Error Crypto detectado en ${canonicalJid}. Resucitando...`, senderId);
            
            // 1. Force Soft Reset
            await softResetConnection(senderId);
            
            // 2. Wait for reconnection (3s)
            await new Promise(r => setTimeout(r, 3000));
            
            // 3. Get New Socket
            const newSock = sessions.get(senderId);
            if (!newSock) throw new Error("No se pudo restablecer la conexión para reintentar el envío.");

            logService.info(`[SELF-HEALING] 🔄 Reintentando envío...`, senderId);
            
            // ATTEMPT 2: Retry with fresh socket
            try {
                const retryResult = await attemptSend(newSock);
                logService.info(`[SELF-HEALING] ✅ Mensaje entregado tras recuperación.`, senderId);
                return retryResult as any;
            } catch (retryError: any) {
                logService.error(`[SELF-HEALING] 💀 Fallo total.`, retryError, senderId);
                throw new Error("Error persistente de conexión: " + retryError.message);
            }
        }
        
        throw e; // If it's a logic error (e.g. JID invalid), throw immediately
    }
}

export async function fetchUserGroups(userId: string): Promise<WhatsAppGroup[]> {
    const sock = sessions.get(userId);
    if (!sock) return [];
    try {
        const groups = await sock.groupFetchAllParticipating();
        return Object.values(groups).map((g: GroupMetadata) => ({
            id: g.id,
            subject: g.subject,
            size: g.participants.length
        }));
    } catch {
        return [];
    }
}

// AI PROCESSOR WRAPPER
export async function processAiResponseForJid(userId: string, jid: string, force: boolean = false) {
    const user = await db.getUser(userId);
    if (!user) return;

    const safeJid = sanitizeKey(jid);
    const conversation = user.conversations?.[safeJid] || user.conversations?.[jid];
    
    if (!conversation) return;

    if (!force) {
        if (!user.settings.isActive) return;
        if (conversation.isMuted || !conversation.isBotActive || conversation.status === LeadStatus.PERSONAL) return;
        
        const lastMsg = conversation.messages[conversation.messages.length - 1];
        if (lastMsg && (lastMsg.sender === 'bot' || lastMsg.sender === 'owner' || lastMsg.sender === 'elite_bot')) return;
    }

    const aiResult = await generateBotResponse(conversation, user, conversation.isTestBotConversation);

    if (aiResult?.responseText) {
        try {
            // HUMAN DELAY & TYPING PRESENCE
            const sock = sessions.get(userId); 
            
            // @ts-ignore
            if (sock && sock.ws && sock.ws.isOpen) {
                await sock.sendPresenceUpdate('composing', jid);
                // Random Delay 2s - 4s
                await new Promise(r => setTimeout(r, 2000 + Math.random() * 2000)); 
            }

            // USE ROBUST SEND
            const sent = await sendMessage(userId, jid, aiResult.responseText);
            
            if (sent?.key.id) {
                await conversationService.addMessage(userId, jid, {
                    id: sent.key.id,
                    text: aiResult.responseText,
                    sender: 'bot',
                    timestamp: new Date().toISOString()
                });
            }
        } catch (e) {
            logService.error(`[AI] Error enviando respuesta a ${jid}`, e, userId);
        }
    }

    if (aiResult) {
        const freshUser = await db.getUser(userId);
        const freshConvo = freshUser?.conversations?.[safeJid] || freshUser?.conversations?.[jid] || conversation;
        
        const updates: any = {
            status: aiResult.newStatus,
            tags: [...new Set([...(freshConvo.tags || []), ...(aiResult.tags || [])])],
            suggestedReplies: undefined
        };

        if (aiResult.newStatus === LeadStatus.HOT && !freshUser?.settings.isAutonomousClosing) {
            updates.isMuted = true;
            updates.suggestedReplies = aiResult.suggestedReplies;
        }

        await db.saveUserConversation(userId, { ...freshConvo, ...updates });
    }
}
