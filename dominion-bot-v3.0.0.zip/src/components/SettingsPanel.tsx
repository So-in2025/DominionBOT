

import React, { useState, useEffect, useRef } from 'react';
import { BotSettings, PromptArchetype, NeuralRouterConfig } from '../types';
import { audioService } from '../services/audioService';
import { openSupportWhatsApp } from '../utils/textUtils';
import AdvancedNeuralConfig from './Settings/AdvancedNeuralConfig';
import { getAuthHeaders, BACKEND_URL } from '../config';

interface SettingsPanelProps {
  token: string;
  settings: BotSettings | null;
  isLoading: boolean;
  onUpdateSettings: (newSettings: BotSettings) => void;
  onOpenLegal: (type: 'privacy' | 'terms' | 'manifesto' | 'network') => void;
  showToast: (message: string, type: 'success' | 'error' | 'info') => void;
}

// --- UTILITY FUNCTIONS ---

const safeJsonParse = (str: string | undefined): any | null => {
    if (!str) return null;
    try {
        // La implementación anterior con `includes` era frágil.
        // Un try/catch es la forma canónica y más robusta de validar JSON.
        return JSON.parse(str);
    } catch {
        return null;
    }
};

// --- CONSTANTS & MAPPINGS ---

const ARCHETYPE_NAMES: { [key in PromptArchetype]: string } = {
    [PromptArchetype.CONSULTATIVE]: 'Venta Consultiva',
    // FIX: Corrected typo 'Promptarchetype' to 'PromptArchetype'.
    [PromptArchetype.DIRECT_CLOSER]: 'Cierre Directo',
    [PromptArchetype.SUPPORT]: 'SOPORTE_TECNICO',
    [PromptArchetype.EMPATHIC]: 'Relacional Empático',
    [PromptArchetype.AGRESSIVE]: 'Cierre Agresivo',
    [PromptArchetype.ACADEMIC]: 'Informativo Detallado',
    [PromptArchetype.CUSTOM]: 'Personalizado',
};

const ARCHETYPE_MAPPING = {
    [PromptArchetype.CONSULTATIVE]: { toneValue: 4, rhythmValue: 4, intensityValue: 2 },
    [PromptArchetype.DIRECT_CLOSER]: { toneValue: 2, rhythmValue: 2, intensityValue: 5 },
    [PromptArchetype.SUPPORT]: { toneValue: 5, rhythmValue: 3, intensityValue: 1 },
    [PromptArchetype.EMPATHIC]: { toneValue: 5, rhythmValue: 4, intensityValue: 2 },
    [PromptArchetype.AGRESSIVE]: { toneValue: 1, rhythmValue: 1, intensityValue: 5 },
    [PromptArchetype.ACADEMIC]: { toneValue: 5, rhythmValue: 5, intensityValue: 1 },
    [PromptArchetype.CUSTOM]: { toneValue: 3, rhythmValue: 3, intensityValue: 3 },
};

// --- ELITE TEMPLATES ---
const INDUSTRY_TEMPLATES: Record<string, { label: string, icon: string, desc: string, data: Partial<WizardState & { priceText: string, ctaLink: string }> }> = {
    'AGENCY': {
        label: 'Agencia High-Ticket',
        icon: '🚀',
        desc: 'Para agencias de marketing, desarrollo o consultoría.',
        data: {
            mission: 'Soy el Consultor Senior de [NOMBRE_EMPRESA]. Mi objetivo es auditar la situación del cliente y ofrecer la solución exacta.',
            idealCustomer: 'Dueños de negocio que buscan escalar, tienen presupuesto y valoran la calidad sobre el precio.',
            detailedDescription: 'Servicios premium de [CONTEXTO_EMPRESA]. Nos enfocamos en el ROI y resultados tangibles. No vendemos horas, vendemos transformación.',
            priceText: 'A convenir según proyecto',
            ctaLink: '',
            objections: [
                { id: 1, objection: 'Es costoso', response: 'Lo costoso es no tener resultados. Nuestra solución se paga sola con el primer cliente que cierres gracias a esto.' },
                { id: 2, objection: '¿Cómo empezamos?', response: 'El primer paso es una auditoría breve para ver si calificas. ¿Te parece bien?' }
            ],
            rules: '- NO dar precios exactos sin calificar primero.\n- Mantener postura de autoridad.\n- Filtrar clientes sin presupuesto.'
        }
    },
    'REAL_ESTATE': {
        label: 'Real Estate / Inmobiliaria',
        icon: '🏙️',
        desc: 'Venta y alquiler de propiedades, terrenos y desarrollos.',
        data: {
            mission: 'Soy el Asesor Inmobiliario de [NOMBRE_EMPRESA]. Conecto personas con oportunidades de inversión o su hogar ideal.',
            idealCustomer: 'Compradores o inversores calificados buscando seguridad jurídica y revalorización.',
            detailedDescription: 'Cartera exclusiva de propiedades en [CONTEXTO_EMPRESA]. Gestión integral y asesoramiento legal incluido.',
            priceText: 'Consultar valor',
            ctaLink: '',
            objections: [
                { id: 1, objection: 'Solo quiero ver fotos', response: 'Entiendo. Para enviarte las fichas correctas y no hacerte perder tiempo, ¿qué presupuesto aproximado estás manejando?' },
                { id: 2, objection: 'La ubicación exacta', response: 'Por seguridad y privacidad de los propietarios, coordinamos una visita presencial para revelar la ubicación exacta.' }
            ],
            rules: '- Calificar solvencia antes de agendar visita.\n- Proyectar exclusividad.'
        }
    },
    'ECOMMERCE': {
        label: 'E-commerce / Retail',
        icon: '🛍️',
        desc: 'Tiendas online, productos físicos, moda y accesorios.',
        data: {
            mission: 'Soy el Asistente de Compras de [NOMBRE_EMPRESA]. Ayudo a elegir el producto perfecto y resolver dudas de envío.',
            idealCustomer: 'Compradores que valoran la calidad, el diseño y la rapidez en la entrega.',
            detailedDescription: 'Venta de [CONTEXTO_EMPRESA]. Envíos a todo el país. Garantía de satisfacción.',
            priceText: 'Ver catálogo',
            ctaLink: '',
            objections: [
                { id: 1, objection: 'Precio del envío', response: 'El envío es rápido y seguro. Además, si tu compra supera cierto monto, ¡es gratis!' },
                { id: 2, objection: '¿Tienen garantía?', response: 'Sí, garantía total de cambio directo si no estás conforme con el producto.' }
            ],
            rules: '- Respuestas cortas y amables.\n- Fomentar la compra impulsiva.'
        }
    },
    'SERVICES': {
        label: 'Servicios Profesionales',
        icon: '⚖️',
        desc: 'Abogados, Contadores, Arquitectos, Salud.',
        data: {
            mission: 'Soy el Asistente de [NOMBRE_EMPRESA]. Gestiono citas y filtro consultas para optimizar el tiempo de los profesionales.',
            idealCustomer: 'Personas con una necesidad específica o urgencia que requieren solución profesional.',
            detailedDescription: 'Estudio/Consultorio especializado en [CONTEXTO_EMPRESA]. Atención personalizada y confidencialidad.',
            priceText: 'Honorarios según caso',
            ctaLink: '',
            objections: [
                { id: 1, objection: 'Precio de la consulta', response: 'Cada caso es único. Ofrecemos una primera evaluación para determinar la viabilidad y el costo exacto.' },
                { id: 2, objection: 'Necesito hablar urgente', response: 'Entendido. Por favor, descríbeme brevemente la urgencia para priorizar tu caso con el especialista.' }
            ],
            rules: '- Tono formal y empático.\n- Priorizar el agendamiento de citas.'
        }
    }
};

// --- TYPES & UTILS ---

interface WizardState {
    mission: string;
    idealCustomer: string;
    detailedDescription: string;
    objections: { id: number; objection: string; response: string }[];
    rules: string;
}

// Polyfill simple para SpeechRecognition
const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

const SettingsPanel: React.FC<SettingsPanelProps> = ({ token, settings, isLoading, onUpdateSettings, onOpenLegal, showToast }) => {
  // UNIFIED STATE: `current` is the single source of truth for all settings.
  const [current, setCurrent] = useState<BotSettings | null>(null);
  
  // WIZARD STATE (for flow control and non-settings data only)
  const [wizardStep, setWizardStep] = useState<'IDENTITY' | 'API_SETUP' | 'CONTEXT' | 'PATH' | 'LOADING'>('IDENTITY');
  const [wizIdentity, setWizIdentity] = useState({ name: '', website: '' });
  const [wizApiKey, setWizApiKey] = useState('');
  const [wizContext, setWizContext] = useState(''); // Only for linear wizard context
  const [isRecording, setIsRecording] = useState(false);
  const [showWebTooltip, setShowWebTooltip] = useState(false);
  const [isAnalyzingWeb, setIsAnalyzingWeb] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // For standard settings saving
  const [isSaving, setIsSaving] = useState(false);
  const recognitionRef = useRef<any>(null);
  const descriptionTextareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-sizing textarea effect based on audit recommendation
  useEffect(() => {
    const textarea = descriptionTextareaRef.current;
    if (textarea) {
        textarea.style.height = 'auto'; // Reset height to allow shrinking
        textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [current?.productDescription]);


  useEffect(() => {
    if (settings) {
        // Initialize the single source of truth.
        // Ensure neuralConfig exists if advanced mode is on but config is missing.
        const initialSettings = { ...settings, ignoredJids: settings.ignoredJids || [] };
        if (initialSettings.useAdvancedModel && !initialSettings.neuralConfig) {
            initialSettings.neuralConfig = { masterIdentity: '', modules: [] };
        }
        setCurrent(initialSettings);

        // Sync wizard-specific states for pre-population if the wizard is ever re-run.
        if (settings.geminiApiKey) setWizApiKey(settings.geminiApiKey);
        if (settings.productName) setWizIdentity(prev => ({ ...prev, name: settings.productName }));
        if (settings.ctaLink) setWizIdentity(prev => ({ ...prev, website: settings.ctaLink }));
    }
  }, [settings]);

  // --- AUDIO RECORDING LOGIC ---
  const toggleRecording = () => {
      if (isRecording) {
          recognitionRef.current?.stop();
          setIsRecording(false);
          recognitionRef.current = null; // Cleanup ref
      } else {
          if (!SpeechRecognition) {
              showToast('Tu navegador no soporta entrada de voz. Usa Chrome.', 'error');
              return;
          }
          const recognition = new SpeechRecognition();
          recognition.lang = 'es-ES';
          recognition.continuous = true;
          recognition.interimResults = true;

          recognition.onresult = (event: any) => {
              let finalTranscript = '';
              for (let i = event.resultIndex; i < event.results.length; ++i) {
                  if (event.results[i].isFinal) {
                      finalTranscript += event.results[i][0].transcript;
                  }
              }
              if (finalTranscript) {
                  setWizContext(prev => prev + ' ' + finalTranscript);
              }
          };

          recognition.onerror = (event: any) => {
              console.error(event.error);
              setIsRecording(false);
              recognitionRef.current = null; // Cleanup ref
          };

          recognition.start();
          recognitionRef.current = recognition;
          setIsRecording(true);
          showToast('Escuchando... Habla sobre tu negocio.', 'info');
      }
  };

  const handleUpdate = (field: keyof BotSettings, value: any) => {
    if (!current) return;
    setCurrent(prev => ({ ...prev!, [field]: value }));
  };

  const handleSaveChanges = async () => {
      if (!current) return;
      setIsSaving(true);
      try {
          const payload = {
              ...current,
              priceText: current.useAdvancedModel ? '' : current.priceText,
          };
          await onUpdateSettings(payload);
          showToast('Configuración sincronizada con el núcleo.', 'success');
          audioService.play('action_success');
      } catch (e) {
          showToast('Error al guardar.', 'error');
      } finally {
          setIsSaving(false);
      }
  };

  // --- WEB ANALYSIS FEATURE ---
  const analyzeWebsite = async () => {
      if (!wizIdentity.website) return;
      if (!wizApiKey) {
          showToast('Falta la API Key. Retrocede un paso.', 'error');
          return;
      }

      setIsAnalyzingWeb(true);
      try {
          const res = await fetch(`${BACKEND_URL}/api/ai/analyze-website`, {
              method: 'POST',
              headers: getAuthHeaders(token!),
              body: JSON.stringify({ websiteUrl: wizIdentity.website })
          });

          if (!res.ok) {
              const errorData = await res.json();
              throw new Error(errorData.message || 'Error del servidor');
          }
          
          const data = await res.json();

          if (data.text) {
              setWizContext(prev => (prev ? prev + '\n\n' : '') + data.text);
              showToast('Sitio web analizado exitosamente.', 'success');
              audioService.play('action_success');
          } else {
              showToast('No se pudo extraer información relevante.', 'error');
          }

      } catch (e: any) {
          showToast(`Error analizando la web: ${e.message || 'Error desconocido'}`, 'error');
      } finally {
          setIsAnalyzingWeb(false);
      }
  };

  // --- PATH A: AI AUTOCOMPLETE ---
  const executeNeuralPath = async () => {
      if (!wizApiKey) {
          showToast('Falta la API Key de Gemini.', 'error');
          setWizardStep('API_SETUP');
          return;
      }
      
      if (!current) return;

      if (current.useAdvancedModel) {
          if (!current.neuralConfig?.masterIdentity) {
              showToast('Debes configurar al menos la Identidad Maestra.', 'error');
              return;
          }
          setWizardStep('LOADING');
          setTimeout(() => {
              const newSettings: BotSettings = {
                  ...current,
                  productName: wizIdentity.name,
                  ctaLink: wizIdentity.website || current.ctaLink,
                  useAdvancedModel: true,
                  geminiApiKey: wizApiKey.trim(),
                  isWizardCompleted: true,
                  priceText: '',
                  productDescription: current.productDescription || '',
              };
              onUpdateSettings(newSettings);
              showToast('🧠 Arquitectura Modular Activada.', 'success');
              audioService.play('action_success');
          }, 1500);
          return;
      }

      if (!wizContext || wizContext.length < 30) {
          showToast('El contexto es muy corto. Escribe o dicta más detalles (mín. 30 caracteres).', 'error');
          return;
      }

      setWizardStep('LOADING');
      setIsProcessing(true);

      try {
          const res = await fetch(`${BACKEND_URL}/api/ai/execute-neural-path`, {
            method: 'POST',
            headers: getAuthHeaders(token!),
            body: JSON.stringify({ identity: wizIdentity, context: wizContext })
          });

          if (!res.ok) {
              const errorData = await res.json();
              throw new Error(errorData.message || 'Error del servidor');
          }

          const data = await res.json();
          const parsedData = safeJsonParse(data?.text);

          if (!parsedData) {
              console.error("JSON Parse Error: AI returned invalid format.", "--- AI Raw Text:", data?.text);
              showToast('Formato AI inválido. Intenta de nuevo.', 'error');
              setWizardStep('CONTEXT');
              return;
          }

          finishWizard(parsedData, 'AI');

      } catch (e: any) {
          console.error(e);
          showToast(`Error en la generación neural: ${e.message}`, 'error');
          setWizardStep('CONTEXT'); 
      } finally {
          setIsProcessing(false);
      }
  };

  // --- PATH B: TEMPLATES ---
  const executeTemplatePath = (templateKey: string) => {
      const t = INDUSTRY_TEMPLATES[templateKey];
      if (!t) return;

      const inject = (text: string = '') => {
          return text
            .replace(/\[NOMBRE_EMPRESA\]/g, wizIdentity.name)
            .replace(/\[CONTEXTO_EMPRESA\]/g, wizContext || 'nuestro rubro');
      };

      const finalData = {
          mission: inject(t.data.mission),
          idealCustomer: t.data.idealCustomer,
          detailedDescription: inject(t.data.detailedDescription),
          priceText: t.data.priceText,
          objections: t.data.objections,
          rules: t.data.rules,
          archetype: 'VENTA_CONSULTIVA' // Default
      };

      finishWizard(finalData, 'TEMPLATE');
  };

  const finishWizard = (data: any, source: 'AI' | 'TEMPLATE') => {
      if (!current) return;

      const compiledDescription = `
## MISIÓN PRINCIPAL
${data.mission}

## CLIENTE IDEAL
${data.idealCustomer || ''}

## DESCRIPCIÓN DETALLADA DEL SERVICIO
${data.detailedDescription}

## MANEJO DE OBJECIONES FRECUENTES
${(data.objections || []).map((obj: any) => `- Sobre "${obj.objection}": Respondo: "${obj.response}"`).join('\n')}

## REGLAS DE ORO Y LÍMITES
${data.rules}
      `;

      const arch = (data.archetype as PromptArchetype) || PromptArchetype.CONSULTATIVE;
      const mapping = ARCHETYPE_MAPPING[arch] || ARCHETYPE_MAPPING[PromptArchetype.CONSULTATIVE];

      const newSettings: BotSettings = {
          ...current,
          productName: wizIdentity.name,
          ctaLink: wizIdentity.website || current.ctaLink,
          productDescription: compiledDescription,
          priceText: data.priceText || current.priceText,
          archetype: arch,
          toneValue: mapping.toneValue,
          rhythmValue: mapping.rhythmValue,
          intensityValue: mapping.intensityValue,
          geminiApiKey: wizApiKey.trim(), 
          isWizardCompleted: true,
          useAdvancedModel: false,
          neuralConfig: { masterIdentity: '', modules: [] }
      };

      onUpdateSettings(newSettings);
      showToast(source === 'AI' ? '🧠 Cerebro Generado y Sincronizado.' : '📂 Plantilla Aplicada Exitosamente.', 'success');
      audioService.play('action_success');
  };

  const TOOLTIP_TEXTS = {
    simple: "Ideal para la mayoría de los negocios. Una sola IA maneja todas las conversaciones con una personalidad y objetivo unificado.",
    advanced: "Para agencias o negocios complejos. Permite crear 'expertos' para diferentes áreas (soporte, ventas, etc.) y un 'router' que dirige al cliente al experto correcto."
  };

  if (isLoading || !current) return <div className="p-10 text-center text-gray-500 animate-pulse font-black uppercase tracking-widest">Cargando Núcleo...</div>;

  // VIEW: MAIN SETTINGS (If Wizard Completed)
  if (current.isWizardCompleted) {
      return (
        <div className="flex-1 bg-brand-black p-4 md:p-8 overflow-y-auto custom-scrollbar font-sans relative z-10 animate-fade-in">
            <div className="max-w-7xl mx-auto pb-32 space-y-8">
                
                <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-white/5 pb-6">
                    <div>
                        <h2 className="text-3xl font-black text-white tracking-tighter uppercase flex items-center gap-3">
                            Configuración <span className="text-brand-gold">Neural</span>
                        </h2>
                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.3em] mt-1">Calibración del Núcleo</p>
                    </div>
                    <div className="flex gap-4">
                        <button 
                            onClick={() => { if(confirm('¿Reiniciar el asistente de configuración?')) { handleUpdate('isWizardCompleted', false); setWizardStep('IDENTITY'); } }} 
                            className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-400 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all"
                        >
                            Reiniciar Wizard
                        </button>
                        <button 
                            onClick={handleSaveChanges} 
                            disabled={isSaving}
                            className="px-6 py-2 bg-brand-gold text-black rounded-lg text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-lg shadow-brand-gold/20 disabled:opacity-50"
                        >
                            {isSaving ? 'Sincronizando...' : 'Guardar Cambios'}
                        </button>
                    </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* LEFT COL: General & Activation */}
                    <div className="space-y-8">
                        <div className="bg-brand-surface border border-white/5 rounded-3xl p-6 shadow-xl">
                            <h3 className="text-sm font-black text-white uppercase tracking-widest mb-6">Identidad y Credenciales</h3>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-[9px] font-black text-brand-gold uppercase tracking-widest mb-1">Nombre Comercial</label>
                                    <input type="text" value={current.productName} onChange={e => handleUpdate('productName', e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-white text-xs font-bold focus:border-brand-gold outline-none" />
                                </div>
                                <div>
                                    <label className="block text-[9px] font-black text-brand-gold uppercase tracking-widest mb-1">Gemini API Key</label>
                                    <input type="password" value={current.geminiApiKey || ''} onChange={e => handleUpdate('geminiApiKey', e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-white text-xs font-mono focus:border-brand-gold outline-none" placeholder="******" />
                                </div>
                            </div>
                        </div>

                        <div className="bg-brand-surface border border-white/5 rounded-3xl p-6 shadow-xl">
                            <h3 className="text-sm font-black text-white uppercase tracking-widest mb-6">Arquitectura</h3>
                            <div className="flex p-1 bg-black/40 border border-white/10 rounded-xl mb-4">
                                <button onClick={() => handleUpdate('useAdvancedModel', false)} className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${!current.useAdvancedModel ? 'bg-white/10 text-white' : 'text-gray-500'}`}>Lineal (Simple)</button>
                                <button onClick={() => handleUpdate('useAdvancedModel', true)} className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${current.useAdvancedModel ? 'bg-brand-gold text-black' : 'text-gray-500'}`}>Modular (Adv)</button>
                            </div>
                            <p className="text-[9px] text-gray-500 leading-relaxed">
                                {current.useAdvancedModel 
                                    ? "Sistema de enrutamiento inteligente. Define múltiples 'expertos' y un nodo maestro." 
                                    : "Modelo unificado. Una sola identidad y contexto para todo el flujo."}
                            </p>
                        </div>
                        
                        {!current.useAdvancedModel && (
                            <div className="bg-brand-surface border border-white/5 rounded-3xl p-6 shadow-xl">
                                <h3 className="text-sm font-black text-white uppercase tracking-widest mb-6">Personalidad</h3>
                                <div className="space-y-6">
                                    {['toneValue', 'rhythmValue', 'intensityValue'].map((field) => (
                                        <div key={field}>
                                            <div className="flex justify-between mb-2">
                                                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest">
                                                    {field === 'toneValue' ? 'Tono (Formal - Amigable)' : field === 'rhythmValue' ? 'Ritmo (Lento - Rápido)' : 'Intensidad (Suave - Agresivo)'}
                                                </label>
                                                <span className="text-[9px] font-mono text-brand-gold">{(current as any)[field]}</span>
                                            </div>
                                            <input 
                                                type="range" min="1" max="5" 
                                                value={(current as any)[field]} 
                                                onChange={e => handleUpdate(field as keyof BotSettings, parseInt(e.target.value))} 
                                                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-brand-gold" 
                                            />
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>

                    {/* RIGHT COL: Main Context / Modular Config */}
                    <div className="lg:col-span-2 space-y-8">
                        {current.useAdvancedModel ? (
                            <AdvancedNeuralConfig 
                                initialConfig={current.neuralConfig}
                                onChange={(cfg) => handleUpdate('neuralConfig', cfg)}
                            />
                        ) : (
                            <div className="bg-brand-surface border border-white/5 rounded-3xl p-8 shadow-xl h-full">
                                <div className="flex justify-between items-center mb-6">
                                    <h3 className="text-sm font-black text-white uppercase tracking-widest">Contexto Unificado (Prompt)</h3>
                                    <span className="text-[9px] text-gray-500 uppercase font-bold tracking-widest">Modelo Lineal</span>
                                </div>
                                <textarea 
                                    ref={descriptionTextareaRef}
                                    value={current.productDescription} 
                                    onChange={e => handleUpdate('productDescription', e.target.value)} 
                                    className="w-full bg-black/50 border border-white/10 rounded-xl p-6 text-white text-xs font-mono leading-relaxed focus:border-brand-gold outline-none resize-none custom-scrollbar overflow-y-hidden"
                                    placeholder="Aquí reside el cerebro de tu bot..."
                                    rows={1}
                                />
                                <div className="grid grid-cols-2 gap-4 mt-6">
                                    <div>
                                        <label className="block text-[9px] font-black text-brand-gold uppercase tracking-widest mb-1">Precio Base (Ref)</label>
                                        <input type="text" value={current.priceText} onChange={e => handleUpdate('priceText', e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-white text-xs focus:border-brand-gold outline-none" />
                                    </div>
                                    <div>
                                        <label className="block text-[9px] font-black text-brand-gold uppercase tracking-widest mb-1">Link de Cierre (CTA)</label>
                                        <input type="text" value={current.ctaLink} onChange={e => handleUpdate('ctaLink', e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-white text-xs focus:border-brand-gold outline-none" />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
      );
  }

  // VIEW: WIZARD
  return (
    <div className="flex-1 bg-brand-black flex flex-col items-center justify-start p-6 md:p-10 pt-24 md:pt-10 relative overflow-y-auto font-sans min-h-full">
        <div className="absolute top-0 left-0 w-full h-full bg-noise opacity-5 pointer-events-none fixed"></div>
        <div className="absolute -top-20 -right-20 w-96 h-96 bg-brand-gold/5 rounded-full blur-[100px] pointer-events-none fixed"></div>

        <div className="w-full max-w-2xl relative z-10">
            
            <div className="mb-10 text-center">
                <h2 className="text-3xl md:text-4xl font-black text-white uppercase tracking-tighter mb-2">
                    Configuración <span className="text-brand-gold">Neural</span>
                </h2>
                <div className="flex justify-center gap-2 mt-4">
                    {['IDENTITY', 'API_SETUP', 'CONTEXT', 'PATH'].map((s, idx) => {
                        const steps = ['IDENTITY', 'API_SETUP', 'CONTEXT', 'PATH'];
                        const currIdx = steps.indexOf(wizardStep);
                        const isActive = idx <= currIdx;
                        return (
                            <div key={s} className={`h-1.5 w-8 rounded-full transition-all duration-500 ${isActive ? 'bg-brand-gold shadow-[0_0_10px_rgba(212,175,55,0.5)]' : 'bg-white/10'}`}></div>
                        );
                    })}
                </div>
            </div>

            <div className={`bg-brand-surface border border-white/10 rounded-[32px] p-8 md:p-12 shadow-2xl relative backdrop-blur-sm transition-all duration-500 ${current.useAdvancedModel && wizardStep === 'CONTEXT' ? 'max-w-4xl w-full mx-auto' : ''}`}>
                
                {wizardStep === 'IDENTITY' && (
                    <div className="space-y-8 animate-fade-in">
                        <div className="text-center">
                            <h3 className="text-xl font-black text-white uppercase tracking-widest">Identidad Digital</h3>
                            <p className="text-xs text-gray-400 mt-2 font-medium">¿Quién eres ante el mundo?</p>
                        </div>

                        <div className="space-y-6">
                            <div>
                                <label className="block text-[10px] font-black text-brand-gold uppercase tracking-widest mb-2 ml-1">Nombre del Negocio</label>
                                <input 
                                    type="text" 
                                    value={wizIdentity.name}
                                    onChange={(e) => setWizIdentity({...wizIdentity, name: e.target.value})}
                                    placeholder="Ej: Agencia Alpha, Inmobiliaria Sur..."
                                    className="w-full bg-black/50 border border-white/10 rounded-xl p-4 text-white text-lg font-bold focus:border-brand-gold outline-none transition-all placeholder-gray-700"
                                    autoFocus
                                />
                            </div>

                            <div className="relative">
                                <label className="block text-[10px] font-black text-brand-gold uppercase tracking-widest mb-2 ml-1">Sitio Web (Opcional)</label>
                                <input 
                                    type="text" 
                                    value={wizIdentity.website}
                                    onChange={(e) => setWizIdentity({...wizIdentity, website: e.target.value})}
                                    onBlur={() => { if(!wizIdentity.website) setShowWebTooltip(true); }}
                                    placeholder="www.tu-negocio.com"
                                    className="w-full bg-black/50 border border-white/10 rounded-xl p-4 text-white text-sm focus:border-brand-gold outline-none transition-all placeholder-gray-700"
                                />
                                {showWebTooltip && !wizIdentity.website && (
                                    <div className="absolute top-0 right-0 -mt-10 md:-mr-4 bg-brand-gold text-black p-3 rounded-xl shadow-lg border border-white/20 animate-bounce cursor-pointer z-20 max-w-[200px]" onClick={() => openSupportWhatsApp('Hola, estoy configurando mi bot y vi que necesito una web profesional. ¿Me das info?')}>
                                        <div className="relative">
                                            <p className="text-[9px] font-black leading-tight uppercase">¿Sin web? Pierdes el 40% de confianza. <span className="underline">Hablemos.</span></p>
                                            <div className="absolute bottom-[-18px] right-4 w-3 h-3 bg-brand-gold rotate-45 transform"></div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        <button 
                            onClick={() => { if(wizIdentity.name) setWizardStep('API_SETUP'); else showToast('El nombre es obligatorio.', 'error'); }}
                            className="w-full py-4 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-[1.02] mt-4"
                        >
                            Siguiente &rarr;
                        </button>
                    </div>
                )}

                {wizardStep === 'API_SETUP' && (
                    <div className="space-y-8 animate-fade-in">
                        <div className="text-center">
                            <h3 className="text-xl font-black text-white uppercase tracking-widest">Motor Cognitivo</h3>
                            <p className="text-xs text-gray-400 mt-2 font-medium max-w-sm mx-auto">
                                Dominion opera con tu propia llave maestra de Google (BYOK). 
                                Esto garantiza privacidad total y control de costos.
                            </p>
                        </div>

                        <div className="bg-black/30 border border-brand-gold/20 p-6 rounded-2xl space-y-4">
                            <div>
                                <label className="block text-[10px] font-black text-brand-gold uppercase tracking-widest mb-2 ml-1">Gemini API Key</label>
                                <input 
                                    type="password"
                                    autoComplete="new-password"
                                    value={wizApiKey}
                                    onChange={(e) => setWizApiKey(e.target.value)}
                                    placeholder="Pegar AI Studio Key aquí..."
                                    className="w-full bg-black/50 border border-white/10 rounded-xl p-4 text-white text-sm font-mono focus:border-brand-gold outline-none transition-all placeholder-gray-700 tracking-wider"
                                />
                            </div>
                            
                            <div className="flex flex-col sm:flex-row gap-3 pt-2">
                                <a 
                                    href="https://aistudio.google.com/app/apikey" 
                                    target="_blank" 
                                    rel="noreferrer"
                                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold text-gray-300 uppercase tracking-wider transition-all"
                                >
                                    <span>🔑</span> Obtener Key Gratis
                                </a>
                                <button 
                                    onClick={() => showToast('Video tutorial próximamente.', 'info')}
                                    className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[10px] font-bold text-gray-300 uppercase tracking-wider transition-all"
                                >
                                    <span>▶️</span> Ver Tutorial (1 min)
                                </button>
                            </div>
                        </div>

                        <div className="flex gap-4 pt-2">
                            <button onClick={() => setWizardStep('IDENTITY')} className="px-6 py-3 text-gray-500 font-bold text-xs uppercase hover:text-white transition-colors">Atrás</button>
                            <button 
                                onClick={() => { 
                                    if(wizApiKey.length > 20) {
                                        handleUpdate('geminiApiKey', wizApiKey.trim());
                                        setWizardStep('CONTEXT'); 
                                    } else {
                                        showToast('Ingresa una API Key válida.', 'error'); 
                                    }
                                }}
                                className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-[1.02]"
                            >
                                Validar & Continuar &rarr;
                            </button>
                        </div>
                    </div>
                )}

                {wizardStep === 'CONTEXT' && (
                    <div className="space-y-6 animate-fade-in relative">
                        <div className="text-center mb-6">
                            <h3 className="text-xl font-black text-white uppercase tracking-widest">Definición de Inteligencia</h3>
                            <p className="text-xs text-gray-400 mt-2 font-medium">Selecciona la arquitectura que mejor se adapte a tu negocio.</p>
                        </div>

                        <div className="grid grid-cols-2 gap-4 mb-6">
                            {/* Simple Button */}
                            <button 
                                onClick={() => handleUpdate('useAdvancedModel', false)}
                                className={`group relative text-center p-6 border rounded-2xl transition-all duration-300 ${!current.useAdvancedModel ? 'bg-brand-gold/10 border-brand-gold shadow-lg shadow-brand-gold/10' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                            >
                                <div className={`mx-auto w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all ${!current.useAdvancedModel ? 'bg-brand-gold text-black' : 'bg-black/40 text-gray-400'}`}>
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                </div>
                                <h4 className="text-sm font-black uppercase tracking-wider text-white">Negocio Único</h4>
                                <p className="text-[10px] text-gray-500 font-bold uppercase">Lineal</p>
                                {/* Desktop Tooltip */}
                                <div className="hidden md:block absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-black border border-white/10 rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 pointer-events-none">
                                    <p className="text-xs text-gray-300 leading-relaxed font-medium text-left">{TOOLTIP_TEXTS.simple}</p>
                                    <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-black border-b border-r border-white/10 rotate-45 -mt-1"></div>
                                </div>
                            </button>

                            {/* Advanced Button */}
                            <button 
                                onClick={() => handleUpdate('useAdvancedModel', true)}
                                className={`group relative text-center p-6 border rounded-2xl transition-all duration-300 ${current.useAdvancedModel ? 'bg-brand-gold/10 border-brand-gold shadow-lg shadow-brand-gold/10' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                            >
                                <div className={`mx-auto w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-all ${current.useAdvancedModel ? 'bg-brand-gold text-black' : 'bg-black/40 text-gray-400'}`}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"> <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" /> </svg>
                                </div>
                                <h4 className="text-sm font-black uppercase tracking-wider text-white">Agencia / Pro</h4>
                                <p className="text-[10px] text-gray-500 font-bold uppercase">Modular</p>
                                {/* Desktop Tooltip */}
                                <div className="hidden md:block absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-3 bg-black border border-white/10 rounded-xl shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50 pointer-events-none">
                                    <p className="text-xs text-gray-300 leading-relaxed font-medium text-left">{TOOLTIP_TEXTS.advanced}</p>
                                    <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-black border-b border-r border-white/10 rotate-45 -mt-1"></div>
                                </div>
                            </button>
                        </div>
                        
                        {/* Mobile Tooltip */}
                        <div className="md:hidden p-4 bg-black/40 border border-white/10 rounded-xl text-center">
                            <p className="text-xs text-gray-300 leading-relaxed font-medium">
                                {!current.useAdvancedModel ? TOOLTIP_TEXTS.simple : TOOLTIP_TEXTS.advanced}
                            </p>
                        </div>

                        {current.useAdvancedModel ? (
                            <div className="pr-2 p-1">
                                <AdvancedNeuralConfig 
                                    initialConfig={current.neuralConfig}
                                    onChange={(cfg) => handleUpdate('neuralConfig', cfg)}
                                    mode="WIZARD"
                                />
                            </div>
                        ) : (
                            <div className="relative group animate-fade-in">
                                {wizIdentity.website && (
                                    <div className="flex justify-end mb-2 px-1">
                                        <button onClick={analyzeWebsite} disabled={isAnalyzingWeb} className="flex items-center gap-2 bg-brand-gold/10 border border-brand-gold/30 hover:bg-brand-gold/20 text-brand-gold px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all disabled:opacity-50">
                                            {isAnalyzingWeb ? (
                                                <>
                                                    <div className="w-3 h-3 border-2 border-brand-gold border-t-transparent rounded-full animate-spin"></div>
                                                    Analizando...
                                                </>
                                            ) : (
                                                <>
                                                    <span className="text-xs">✨</span> Analizar {wizIdentity.website}
                                                </>
                                            )}
                                        </button>
                                    </div>
                                )}
                                <textarea 
                                    value={wizContext}
                                    onChange={(e) => setWizContext(e.target.value)}
                                    className="w-full h-48 bg-black/50 border border-white/10 rounded-xl p-5 pb-12 text-white text-sm leading-relaxed focus:border-brand-gold outline-none resize-none custom-scrollbar placeholder-gray-700 transition-all z-10 relative"
                                    placeholder={`Ej: Soy una agencia de marketing. Vendemos gestión de redes desde $300 USD. Quiero que el bot sea agresivo en el cierre. Si preguntan por descuentos, diles que no, pero que ofrecemos garantía.`}
                                />
                                <button onClick={toggleRecording} className={`absolute bottom-4 right-4 p-3 rounded-full shadow-lg transition-all z-30 ${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-brand-gold text-black hover:scale-110'}`} title="Dictar por voz">
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                                </button>
                            </div>
                        )}

                        <div className="flex gap-4 pt-4 border-t border-white/5">
                            <button onClick={() => setWizardStep('API_SETUP')} className="px-6 py-3 text-gray-500 font-bold text-xs uppercase hover:text-white transition-colors">Atrás</button>
                            {current.useAdvancedModel ? (
                                <button onClick={executeNeuralPath} className="flex-1 py-3 bg-brand-gold text-black rounded-xl font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-[1.02] shadow-lg shadow-brand-gold/20">
                                    Finalizar Arquitectura
                                </button>
                            ) : (
                                <button onClick={() => { if(wizContext.length > 30) setWizardStep('PATH'); else showToast('Danos un poco más de contexto (mín. 30 caracteres).', 'error'); }}
                                    className="flex-1 py-3 bg-white/10 hover:bg-white/20 text-white border border-white/10 rounded-xl font-black text-xs uppercase tracking-[0.2em] transition-all hover:scale-[1.02]"
                                >
                                    Siguiente &rarr;
                                </button>
                            )}
                        </div>
                    </div>
                )}
                
                {wizardStep === 'PATH' && (
                    <div className="space-y-8 animate-fade-in">
                        <div className="text-center mb-8">
                            <h3 className="text-xl font-black text-white uppercase tracking-widest">Estrategia Lineal</h3>
                            <p className="text-xs text-gray-400 mt-2 font-medium">¿Cómo quieres construir el cerebro de tu agente único?</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <button 
                                onClick={executeNeuralPath}
                                className="group relative bg-[#0a0a0a] border border-brand-gold/30 hover:border-brand-gold hover:bg-brand-gold/5 rounded-2xl p-6 text-left transition-all duration-300 hover:-translate-y-1 shadow-[0_0_30px_rgba(0,0,0,0.5)]"
                            >
                                <div className="absolute top-4 right-4 text-2xl group-hover:scale-125 transition-transform">⚡</div>
                                <h4 className="text-lg font-black text-white mb-2 group-hover:text-brand-gold transition-colors">Auto-Completado Neural</h4>
                                <p className="text-xs text-gray-400 leading-relaxed group-hover:text-gray-300">
                                    La IA analiza tu contexto y deduce automáticamente tu Misión, Reglas y Manejo de Objeciones.
                                </p>
                                <div className="mt-6 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-brand-gold/70 group-hover:text-brand-gold">
                                    <span>Recomendado</span> &rarr;
                                </div>
                            </button>

                            <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 text-left relative overflow-hidden">
                                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-gray-800 to-gray-600"></div>
                                <h4 className="text-lg font-black text-white mb-4">Biblioteca Táctica</h4>
                                <div className="grid grid-cols-1 gap-2 max-h-[180px] overflow-y-auto custom-scrollbar pr-2">
                                    {Object.entries(INDUSTRY_TEMPLATES).map(([key, tpl]) => (
                                        <button 
                                            key={key}
                                            onClick={() => executeTemplatePath(key)}
                                            className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/20 transition-all text-left group"
                                        >
                                            <span className="text-xl group-hover:scale-110 transition-transform">{tpl.icon}</span>
                                            <div>
                                                <p className="text-xs font-bold text-white uppercase tracking-tight">{tpl.label}</p>
                                                <p className="text-[9px] text-gray-500 truncate max-w-[120px]">{tpl.desc}</p>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>
                        
                        <div className="text-center pt-4">
                            <button onClick={() => setWizardStep('CONTEXT')} className="text-gray-500 font-bold text-xs uppercase hover:text-white transition-colors">Atrás</button>
                        </div>
                    </div>
                )}

                {wizardStep === 'LOADING' && (
                    <div className="py-20 text-center animate-fade-in flex flex-col items-center">
                        <div className="w-20 h-20 border-4 border-brand-gold/20 border-t-brand-gold rounded-full animate-spin mb-8 shadow-[0_0_40px_rgba(212,175,55,0.2)]"></div>
                        <h3 className="text-xl font-black text-white uppercase tracking-widest animate-pulse">Estructurando Red Neural</h3>
                        <p className="text-xs text-gray-500 mt-3 font-mono">Aplicando arquitectura {current.useAdvancedModel ? 'Modular' : 'Elite'}...</p>
                    </div>
                )}

                {wizardStep !== 'LOADING' && (
                     <div className="mt-8 pt-6 border-t border-white/5 flex justify-center animate-fade-in">
                        <button 
                            onClick={() => openSupportWhatsApp('Hola, estoy trabado en la configuración del Cerebro. ¿Me ayudan con una auditoría?')} 
                            className="text-[9px] text-gray-500 hover:text-brand-gold font-bold uppercase tracking-widest flex items-center gap-2 transition-colors group"
                        >
                            <span className="grayscale group-hover:grayscale-0 transition-all">🆘</span> ¿Te sientes abrumado? Solicitar Auditoría Humana
                        </button>
                    </div>
                )}

            </div>
        </div>
    </div>
  );
};

export default SettingsPanel;
