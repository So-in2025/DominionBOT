
// DEPRECATED
// Logic moved to src/services/aiService.ts (Server Side)
// This file is kept only to prevent build errors if referenced elsewhere, but should be removed.
export const getBotResponse = async () => {
    throw new Error("Client side generation is disabled in Production mode.");
};
